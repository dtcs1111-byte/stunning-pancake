const http = require("http");
const fs = require("fs");
const path = require("path");
const WebSocket = require("ws");

const PORT = process.env.PORT || 10000;
const WORLD_WIDTH = 4000;
const WORLD_HEIGHT = 4000;
const FOOD_COUNT = 180;

const players = new Map();
const foods = new Map();

function makeFood() {
  return {
    id: Math.random().toString(36).slice(2),
    x: 30 + Math.random() * (WORLD_WIDTH - 60),
    y: 30 + Math.random() * (WORLD_HEIGHT - 60),
    size: 4 + Math.random() * 4,
    color: ["#facc15", "#fb7185", "#60a5fa", "#4ade80", "#c084fc"][
      Math.floor(Math.random() * 5)
    ]
  };
}

for (let i = 0; i < FOOD_COUNT; i++) {
  const food = makeFood();
  foods.set(food.id, food);
}

const server = http.createServer((req, res) => {
  const requestPath = decodeURIComponent((req.url || "/").split("?")[0]);
  const filePath = requestPath === "/" ? "/index.html" : requestPath;
  const safePath = path.join(__dirname, path.normalize(filePath).replace(/^(\.\.[/\\])+/, ""));
  if (!safePath.startsWith(__dirname)) {
    res.writeHead(403);
    return res.end("Forbidden");
  }
  fs.readFile(safePath, (err, data) => {
    if (err) {
      res.writeHead(404, { "Content-Type": "text/plain; charset=utf-8" });
      return res.end("Not found");
    }
    const ext = path.extname(safePath).toLowerCase();
    const types = {
      ".html": "text/html; charset=utf-8",
      ".js": "text/javascript; charset=utf-8",
      ".css": "text/css; charset=utf-8",
      ".json": "application/json; charset=utf-8"
    };
    res.writeHead(200, { "Content-Type": types[ext] || "application/octet-stream" });
    res.end(data);
  });
});

const wss = new WebSocket.Server({ server });

function sendState() {
  const playerObject = Object.fromEntries(players);
  const foodObject = Object.fromEntries(foods);
  const message = JSON.stringify({
    type: "state",
    players: playerObject,
    foods: foodObject
  });
  for (const client of wss.clients) {
    if (client.readyState === WebSocket.OPEN) client.send(message);
  }
}

function sendNotice(text) {
  const message = JSON.stringify({ type: "notice", text });
  for (const client of wss.clients) {
    if (client.readyState === WebSocket.OPEN) client.send(message);
  }
}

wss.on("connection", (socket) => {
  socket.on("message", (raw) => {
    let msg;
    try {
      msg = JSON.parse(raw.toString());
    } catch {
      return;
    }

    if (msg.type === "join" && typeof msg.id === "string") {
      socket.playerId = msg.id;
      sendNotice("새로운 커비가 공용 서버에 들어왔어요!");
      sendState();
      return;
    }

    if (msg.type === "player" && typeof msg.id === "string" && msg.player) {
      const p = msg.player;
      const clean = {
        x: Number(p.x) || 0,
        y: Number(p.y) || 0,
        angle: Number(p.angle) || 0,
        score: Math.max(0, Number(p.score) || 0),
        kills: Math.max(0, Number(p.kills) || 0),
        stars: Math.max(0, Number(p.stars) || 0),
        length: Math.max(3, Math.min(250, Number(p.length) || 3)),
        color: typeof p.color === "string" ? p.color.slice(0, 30) : "#ffb6c1",
        skinType: typeof p.skinType === "string" ? p.skinType.slice(0, 20) : "default",
        pathHistory: Array.isArray(p.pathHistory)
          ? p.pathHistory.slice(0, 150).map(pos => ({
              x: Number(pos.x) || 0,
              y: Number(pos.y) || 0,
              angle: Number(pos.angle) || 0
            }))
          : []
      };
      players.set(msg.id, clean);
      return;
    }

    if (msg.type === "eat" && typeof msg.foodId === "string") {
      foods.delete(msg.foodId);
      const food = makeFood();
      foods.set(food.id, food);
      return;
    }

    if (msg.type === "kill" && typeof msg.targetId === "string") {
      const target = players.get(msg.targetId);
      if (target) target.kills = (target.kills || 0) + 1;
      return;
    }

    if (msg.type === "leave" && typeof msg.id === "string") {
      players.delete(msg.id);
      sendState();
    }
  });

  socket.on("close", () => {
    if (socket.playerId) players.delete(socket.playerId);
    sendState();
  });
});

setInterval(sendState, 100);

server.listen(PORT, "0.0.0.0", () => {
  console.log(`Kirby global server listening on ${PORT}`);
});
