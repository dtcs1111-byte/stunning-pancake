const http = require('http');
const fs = require('fs');
const path = require('path');
const { WebSocketServer } = require('ws');

const PORT = process.env.PORT || 3000;
const WORLD_WIDTH = 4000;
const WORLD_HEIGHT = 4000;
const ROOT = __dirname;
const players = new Map();
const foods = new Map();
let nextFoodId = 1;
const colors = ['#fbbf24', '#f87171', '#60a5fa', '#34d399', '#c084fc'];

const server = http.createServer((req, res) => {
  if (req.url === '/health' || req.url === '/healthz') {
    res.writeHead(200, { 'content-type': 'text/plain; charset=utf-8' });
    return res.end('ok');
  }
  if (req.url === '/' || req.url === '/index.html') {
    res.writeHead(200, {
      'content-type': 'text/html; charset=utf-8',
      'cache-control': 'no-store',
      'x-content-type-options': 'nosniff'
    });
    return fs.createReadStream(path.join(ROOT, 'index.html')).pipe(res);
  }
  res.writeHead(404, { 'content-type': 'text/plain; charset=utf-8' });
  res.end('Not found');
});

const wss = new WebSocketServer({ server, maxPayload: 64 * 1024 });
function send(ws, data) {
  if (ws.readyState === 1) ws.send(JSON.stringify(data));
}
function broadcast() {
  const payload = JSON.stringify({
    type: 'state',
    players: Object.fromEntries(players),
    foods: Object.fromEntries(foods)
  });
  for (const client of wss.clients) {
    if (client.readyState === 1) client.send(payload);
  }
}

wss.on('connection', (ws) => {
  let clientId = null;
  let lastPlayerUpdate = 0;
  ws.on('message', (raw) => {
    let msg;
    try { msg = JSON.parse(raw.toString()); } catch { return; }
    if (!msg || typeof msg.type !== 'string') return;

    if (msg.type === 'join' && typeof msg.id === 'string') {
      const requested = msg.id.slice(0, 40);
      if (!requested) return;
      clientId = requested;
      send(ws, { type: 'notice', text: '공용 서버에 입장했어요!' });
      broadcast();
      return;
    }

    if (!clientId) return;
    if (msg.type === 'player' && msg.id === clientId && msg.player) {
      const now = Date.now();
      if (now - lastPlayerUpdate < 40) return;
      lastPlayerUpdate = now;
      const p = msg.player;
      if (![p.x, p.y, p.angle, p.score, p.length].every(Number.isFinite)) return;
      const history = Array.isArray(p.pathHistory) ? p.pathHistory.slice(0, 150)
        .filter(q => q && Number.isFinite(q.x) && Number.isFinite(q.y))
        .map(q => ({ x: Math.max(0, Math.min(WORLD_WIDTH, q.x)), y: Math.max(0, Math.min(WORLD_HEIGHT, q.y)), angle: Number(q.angle) || 0 })) : [];
      players.set(clientId, {
        x: Math.max(0, Math.min(WORLD_WIDTH, p.x)),
        y: Math.max(0, Math.min(WORLD_HEIGHT, p.y)),
        angle: p.angle,
        score: Math.max(0, Math.floor(p.score)),
        kills: Math.max(0, Math.floor(p.kills || 0)),
        stars: Math.max(0, Math.floor(p.stars || 0)),
        length: Math.max(3, Math.min(300, Math.floor(p.length))),
        color: typeof p.color === 'string' ? p.color.slice(0, 24) : '#ffb6c1',
        skinType: typeof p.skinType === 'string' ? p.skinType.slice(0, 24) : 'default',
        pathHistory: history
      });
      return;
    }
    if (msg.type === 'eat' && typeof msg.foodId === 'string') {
      foods.delete(msg.foodId.slice(0, 64));
      return;
    }
    if (msg.type === 'leave') {
      players.delete(clientId);
      clientId = null;
      broadcast();
    }
  });
  ws.on('close', () => {
    if (clientId) players.delete(clientId);
    broadcast();
  });
});

// Shared stars are generated once and seen by everyone in the same world.
setInterval(() => {
  if (foods.size < 65) {
    const online = [...players.values()];
    let cx = WORLD_WIDTH / 2;
    let cy = WORLD_HEIGHT / 2;
    if (online.length) {
      const sample = online[Math.floor(Math.random() * online.length)];
      cx = sample.x;
      cy = sample.y;
    }
    const x = Math.max(25, Math.min(WORLD_WIDTH - 25, cx + (Math.random() - 0.5) * 1000));
    const y = Math.max(25, Math.min(WORLD_HEIGHT - 25, cy + (Math.random() - 0.5) * 750));
    const id = 'star-' + nextFoodId++;
    foods.set(id, { x, y, color: colors[Math.floor(Math.random() * colors.length)], size: Math.random() * 3 + 5 });
  }
}, 550);
setInterval(broadcast, 100);
server.listen(PORT, '0.0.0.0', () => console.log(`Kirby game server listening on ${PORT}`));
