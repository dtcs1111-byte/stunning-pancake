커비 온라인 월드 - 단일 서버 버전

구성
- index.html: 게임 화면
- server.js: 모두가 함께 접속하는 공용 WebSocket 서버 + 웹사이트 제공
- package.json: 실행 설정
- render.yaml: Render 무료 웹 서비스 설정

중요
이 프로젝트는 Firebase를 사용하지 않습니다. 게임 웹사이트와 실시간 서버가 같은 주소에서 실행됩니다.
HTTPS로 접속하면 WebSocket도 자동으로 WSS를 사용합니다.

실행
1. 이 폴더 전체를 GitHub 저장소에 올립니다.
2. Render에서 New > Blueprint 또는 Web Service로 저장소를 연결합니다.
3. Root Directory는 kirby-ws-server 폴더(저장소 루트가 이 폴더면 비워 둠), Build Command는 npm install, Start Command는 npm start로 설정합니다.
4. 배포가 완료되면 Render가 준 https://...onrender.com 주소가 게임 전용 사이트 주소입니다.
5. 그 주소로 접속하면 바로 같은 공용 월드에 들어갑니다. 주소를 친구에게 보내면 됩니다.

참고
무료 서비스는 일정 시간 접속이 없으면 잠들 수 있어 첫 접속이 느릴 수 있습니다. Render 계정에서 배포를 승인해야 공개 주소가 발급됩니다.
